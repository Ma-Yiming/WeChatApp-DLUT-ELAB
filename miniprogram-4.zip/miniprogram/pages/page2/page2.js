// pages/page2/page2.js
const db = wx.cloud.database()
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    height:20,
    name:'',
    id:'',
    sex:'',
    class:'',
    group:['软件组','电子组'],
    openid:'',
    picker_index:0,
    phonenum:'',
    flag:0,
    dowhat:'',
    intro:'',
    prize:'',
    reason:'',
    user:"",
    placeholder:["姓名","学号","性别","班级，如电信1903","学生职务","电话号码","个人简介","获得奖项","加入科中原因（50字左右即可）"]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      user:app.globalData.user
    })
    let user = this.data.user;
    console.log(user)
    if(user){
      this.setData({
        flag:1,
        name:user.name,
        id:user.id,
        sex:user.sex,
        class:user.class,
        dowhat:user.dowhat,
        phonenum:user.phonenum,
        picker_index:user.select,
        intro:user.intro,
        reason:user.reason,
        prize:user.prize
      })
      /* wx.redirectTo({
        url: '../page2_change/page2_change?name='+user.name+'&id='+user.id+'&sex='+user.sex+'&class'+user.class+'&dowhat'+user.dowhat+'&phonenum='+user.phonenum+'&picker_index='+user.select+'&intro='+user.intro+'&reason='+user.reason+'&prize='+user.prize
      }) */
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  formSubmit: function (e) {
    var that = this;
    let openid = app.globalData.openid;
    console.log(openid)
    let flag = this.data.flag;
    var user = this.data.user;
    var stu_id = 0
    console.log(e)
    if (e.detail.value.name != "" && e.detail.value.id != "" && e.detail.value.sex != "" && e.detail.value.phonenum != "" && e.detail.value.classes !=""&&e.detail.value.intro!="" &&e.detail.value.zhiwu!="" && e.detail.value.prize != "" && e.detail.value.reason != "") {
      if(e.detail.value.sex == "男" || e.detail.value.sex == "女"){
        db.collection("Stu").where({
          openid:openid
        }).get({
          success:function(res){
            console.log(res)
            if(res.data.length > 0){
              stu_id = res.data[0]._id
            db.collection("Stu").doc(stu_id).update({
              data:{
              openid: openid,
              name: e.detail.value.name,
              id: e.detail.value.id,
              sex: e.detail.value.sex,
              class: e.detail.value.classes,
              dowhat: e.detail.value.zhiwu,
              phonenum: e.detail.value.phonenum,
              intro: e.detail.value.intro,
              select: that.data.picker_index,
              reason: e.detail.value.reason,
              prize: e.detail.value.prize,
              },
              success:function(res){
              that.setData({
                flag:1,
                name: e.detail.value.name,
                sex: e.detail.value.sex,
                class: e.detail.value.classes,
                picker_index: that.data.picker_index,
                phonenum: e.detail.value.phonenum,
                id: e.detail.value.id,
                dowhat: e.detail.value.zhiwu,
                prize: e.detail.value.prize,
                reason: e.detail.value.reason,
                intro: e.detail.value.intro
              })
              app.globalData.user.name = e.detail.value.name,
              app.globalData.user.id = e.detail.value.id,
              app.globalData.user.sex = e.detail.value.sex,
              app.globalData.user.class = e.detail.value.classes,
              app.globalData.user.dowhat = e.detail.value.zhiwu,
              app.globalData.user.phonenum = e.detail.value.phonenum,
              app.globalData.user.select = that.data.picker_index
              app.globalData.user.intro = e.detail.value.intro,
              app.globalData.user.reason = e.detail.value.reason,
              app.globalData.user.prize = e.detail.value.prize,
              wx.showToast({
                title: '修改成功',
                icon: 'success',
                duration: 2000
              })
                console.log(res)
              },
            fail: function (res) {
              console.log(res);
              wx.showToast({
                title: '修改失败',
                image: '/images/fail.png',
                icon: 'fail',
                duration: 2000})
                }
            })
            }else{
              console.log("进入提交函数")
              console.log(e)
              db.collection('Stu').add({
                data:{
                  openid: openid,
                  name: e.detail.value.name,
                  id: e.detail.value.id,
                  sex: e.detail.value.sex,
                  class: e.detail.value.classes,
                  dowhat: e.detail.value.zhiwu,
                  phonenum: e.detail.value.phonenum,
                  intro: e.detail.value.intro,
                  select: that.data.picker_index,
                  reason: e.detail.value.reason,
                  prize: e.detail.value.prize,
                  //第一次提交都初始化为-1，标记为没有选
                  interviewNum: -1
                },
                success: function (res) {
                  console.log("提交成功");
                  that.setData({
                    flag:1,
                    name: e.detail.value.name,
                    sex: e.detail.value.sex,
                    class: e.detail.value.classes,
                    picker_index: that.data.picker_index,
                    phonenum: e.detail.value.phonenum,
                    id: e.detail.value.id,
                    dowhat: e.detail.value.zhiwu,
                    prize: e.detail.value.prize,
                    reason: e.detail.value.reason,
                    intro: e.detail.value.intro
                  })
                  db.collection('Stu').where({
                    openid:openid
                  }).get({
                    success: function(res){
                      //返回当时的报名表以及选择的面试序号
                      console.log(res)
                      //此人没有用这个openid报过名
                      if(res.data == []){
                        app.globalData.user = ''
                      }
                      else{
                        //这里返回的是数组，取第一个
                        app.globalData.user = res.data[0]
                      }
                      console.log(app.globalData.user)
                    }
                  })
                  wx.showToast({
                    title: '提交成功',
                    icon: 'success',
                    duration: 2000
                  })
                },
                fail: function (res) {
                  //console.log(res);
                  wx.showToast({
                    title: '提交失败',
                    image: '/images/fail.png',
                    icon: 'fail',
                    duration: 2000})}
              })
            }
          }
        }) 
      }else{
        wx.showToast({
          title: '请填写物理性别',
          icon: 'success',
          image:"../../images/fail.png",
          duration: 2000
        })
      }
    }else{
      wx.showToast({
        title: '请完整填写',
        icon: 'success',
        image:"../../images/fail.png",
        duration: 2000
      })
    }
  },
  change: function(){
    this.setData({
      flag:0
    })
  },
  pickerChange: function (e) {
    var that = this;
    that.setData({
      picker_index: e.detail.value
    })
  }
})
