// pages/admin_manage/admin_manage.js
const db = wx.cloud.database()
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    admin:[],
    search:"",
    adminShowing:[],
    level:0,
    openid:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    this.getallAdmin();
    this.setData({
      level:app.globalData.level,
      openid:app.globalData.openid,
    })
  },
  getallAdmin: function(){
    var that = this;
    wx.cloud.callFunction({
      name:'GetAll',
      data:{
        database:'admin',
      }
    }).then(res=>{
      //console.log(res.result.data)
      that.setData({
        admin:res.result.data,
        adminShowing:res.result.data
      })
      console.log(that.data.admin,that.data.adminShowing)
      //res就将appid和openid返回了
      //做一些后续操作，不用考虑代码的异步执行问题。
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  bindTextAreaBlur: function(e){
    this.data.search = e.detail.value;
  },
  search: function(){
    let admin = this.data.admin;
    let name = this.data.search;
    var adminShowing = [];
    for(var i = 0; i < admin.length; i++){
      if(admin[i].name == name){
        adminShowing.push(admin[i])
      }
    }
    this.setData({
      adminShowing:adminShowing
    })
  },
  setlev1:function(e){
    var that = this;
    let openid = e.target.dataset.openid;
    var admin_id = 0
    db.collection("Sup_admin").where({
      openid: openid
    }).get({
      success:function(res){
        if(res.data.length > 0 ){
          admin_id = res.data[0]._id
        }
        db.collection("Sup_admin").doc(admin_id).remove({
          success:function(res){
            //console.log(111111111111)
          }
        })
        wx.showModal({
          content: '修改成功',
          showCancel: false
        })
      }
    })
  },
  setlev2:function(e){
    var that = this;
    let openid = e.target.dataset.openid;
    var admin = ""
    var admin_id = 0
    db.collection("admin").where({
      openid: openid
    }).get({
      success:function(res){
        admin = res.data[0]
        db.collection("Sup_admin").add({
          data:{
            group:admin.group,
            id:admin.id,
            name:admin.name,
            openid:admin.openid
          }
        })
        wx.showModal({
          content: '修改成功',
          showCancel: false
        })
      }
    })
  }
})