// pages/result/result.js
const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:app.globalData.user.name,
    user:app.globalData.user,
    group:"",
    ans:"",
    nowtime:'',
    all_time: [],
    userinterviewtime:"",
    userinterviewdate:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    this.getAllTime();
    var all_time = this.data.all_time;
    var user = this.data.user;
    this.setData({
      nowtime: app.globalData.nowtime
    })
    this.setData({
      name : app.globalData.user.name
    })
    if(that.data.group == 0){
      this.setData({
        group : "软件组"
      })
    }else{
      this.setData({
        group : "电子组"
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getAllTime: function () {
    wx.showLoading({
      title: '加载中',
    });
    //console.log("test");
    var that = this;
    let user = app.globalData.user;
    db.collection('InterviewTime').get({
      success: function(res){
        wx.stopPullDownRefresh();
        wx.hideLoading();
        wx.setStorage({
          key: 'allTime',
          data: res.data
        });
        that.setData({
          all_time: res.data,
        })
        for(var i = 0; i<res.data.length;i++){
          if(user.interviewNum == res.data[i].num){
            console.log(11111111)
            that.setData({
              userinterviewtime: res.data[i].time,
              userinterviewdate: res.data[i].date
            })
            break
          }
        }
      },fail: function () {
        wx.stopPullDownRefresh();
        wx.hideLoading();
        wx.getStorage({
          key: 'allTime',
          success: function (res) {
            that.setData({
              all_time: res.data,
            })
          },
          fail: function () {
            wx.showToast({
              title: '获取时间失败',
              image: '/images/fail.png',
              icon: 'fail',
              duration: 2000
            });
          }
        })
      }
    })    
  }
})