const db = wx.cloud.database()
Page({
  data: {
    multiIndex: [0, 0, 0],
    date: '',
    time: '',
    capacity:100,
    num:0,
    name1:'',
    name2:'',
    name3:'',
    name4:'',
    name5:'',
    name6:'',
    name7:'',
    last:0
  },

  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  bindTimeChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time: e.detail.value
    })
  },
  bindTextAreaBlur: function (e) {
    this.data.capacity = parseInt(e.detail.value);
    
  },
  bindTextAreaBlur2: function (e) {
    this.data.num = e.detail.value;

  },
  bindTextAreaBlur3: function (e) {
    this.data.name1 = e.detail.value;

  },
  bindTextAreaBlur4: function (e) {
    this.data.name2 = e.detail.value;

  },
  bindTextAreaBlur5: function (e) {
    this.data.name3 = e.detail.value;

  },
  bindTextAreaBlur6: function (e) {
    this.data.name4 = e.detail.value;

  },
  bindTextAreaBlur7: function (e) {
    this.data.name5 = e.detail.value;

  },
  bindTextAreaBlur8: function (e) {
    this.data.name6 = e.detail.value;

  },
  bindTextAreaBlur9: function (e) {
    this.data.name7 = e.detail.value;

  },
  add: function () {


    var that = this;
     //console.log(that.data.num);
     db.collection('InterviewTime').add({
      data:{
        date:this.data.date,
        time:this.data.time,
        capacity:this.data.capacity,
        num:this.data.num,
        name1:this.data.name1,
        name2:this.data.name2,
        name3:this.data.name3,
        name4:this.data.name4,
        name5:this.data.name5,
        name6:this.data.name6,
        name7:this.data.name7,
        last:this.data.capacity
      },
      success: function (res) {
        console.log(res);
        wx.showToast({
          title: '提交成功',
          icon: 'success',
          duration: 2000
        })
      },
      fail: function (res) {
        //console.log(res);
        wx.showToast({
          title: '提交失败',
          image: '/images/fail.png',
          icon: 'fail',
          duration: 2000})}
    })
      
  },
  check:function()
  {
      wx.redirectTo({
        url: '../seeschedule/seeschedule',
      })
  }
})