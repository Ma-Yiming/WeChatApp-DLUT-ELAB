// pages/admin_register/admin_register.js
const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    group:'',
    id:'',
    name:'',
    openid:'',
    //表示是否已经上传过了
    flag: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    this.setData({
      openid:app.globalData.openid,
    })
    var openid = this.data.openid;
    db.collection("admin").where({
      openid:openid
    }).get({
      success:function(res){
        console.log(res)
        if (res.data.length > 0)
        {
          that.setData({
            name: res.data[0].name,
            id:res.data[0].id,
            group:res.data[0].group,
            flag:1
          })
        }
        console.log(that.data.name,that.data.id)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //姓名
  bindTextAreaBlur0: function (e) {
    this.data.name = e.detail.value;
  },
  //学号
  bindTextAreaBlur1: function (e) {
    this.data.id = e.detail.value;
  },
  //组别
  bindTextAreaBlur2: function (e) {
    this.data.group = e.detail.value;
  },
  upload: function(){
    var that = this;
    var admin_id = 0;
    var flag = that.data.flag;
    //所有的一切都已经设置好了，就差打包，但是有可能有人重复提交，所以需要更新
    console.log(that.data.openid,that.data.name,that.data.id,that.data.group,flag)
    if(that.data.name != "" && that.data.id != "" && that.data.group != ""){
      if(flag == 0){
        db.collection("admin").add({
          data:{
            openid:that.data.openid,
            name:that.data.name,
            id:that.data.id,
            group:that.data.group
          },
          success:function(res){
            console.log(res)
            that.setData({
              flag:1
            })
            app.globalData.admin.name = this.data.name
            app.globalData.admin.id = this.data.id
            app.globalData.admin.group = this.data.group
            wx.showToast({
              title: '提交成功',
              icon: 'success',
              duration: 2000
            })
          }
        })
      }else if(flag == 1){
        db.collection("admin").where({
          openid:that.data.openid
        }).get({
          success:function(res){
            admin_id = res.data[0]._id,
            db.collection("admin").doc(admin_id).update({
              data:{
                name:that.data.name,
                id:that.data.id,
                group:that.data.group
              },
              success:function(res){
                console.log(res)
                wx.showToast({
                  title: '修改成功',
                  icon: 'success',
                  duration: 2000
                })
              }
            })
          }
        })
      }
    }else{
      wx.showToast({
        title: '格式错误',
        icon: 'success',
        image:"../../images/fail.png",
        duration: 2000
      })
    }
  }
})