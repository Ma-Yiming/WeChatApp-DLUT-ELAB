var app=getApp()
var util = require('../../utils/utils.js')
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    all_time: "",
    openid:'',
    starttime:'',
    nowtime: '',
    endtime: '',
    stutime: 0,
    user: "",
    flag:1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var nowtime = util.formatTime(new Date());
   // console.log(nowtime)
    this.getAllTime();
    this.setData({
      user : app.globalData.user
    })
    this.setData({
      starttime:app.globalData.starttime,
      endtime:app.globalData.endtime,
      nowtime:nowtime
    })
    if(that.data.starttime<=that.data.nowtime&&that.data.nowtime<=that.data.endtime){
      that.setData({
        flag:1
      })
    }else{
      that.setData({
        flag:0
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var that=this;
    wx.showLoading({
      title: '加载中',
    });
    var nowtime = util.formatTime(new Date());
    //console.log(nowtime)
    db.collection("OpenTime").get({
      success:function(res){
        //console.log(res.data[0])
        let start = res.data[0].StartDate+' '+res.data[0].StartTime;
        start = start.replace(/-/g, '/');
        var starttime = util.formatTime(new Date(start));
        let end = res.data[0].EndDate+' '+res.data[0].EndTime;
        end = end.replace(/-/g, '/');
        var endtime = util.formatTime(new Date(end));
        that.setData({
          starttime:starttime,
          endtime:endtime,
          nowtime:nowtime
        })
        //console.log(that.data.starttime,that.data.endtime)
        console.log(that.data.nowtime,that.data.starttime,that.data.endtime)
      }
    })
    this.getAllTime();
    wx.stopPullDownRefresh();
    wx.hideLoading();
    console.log(that.data.all_time)
    if(that.data.starttime<=that.data.nowtime&&that.data.nowtime<=that.data.endtime){
      that.setData({
        flag:1
      })
    }else{
      that.setData({
        flag:0
      })
    }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
getAllTime: function () {
  wx.showLoading({
    title: '加载中',
  });
  //console.log("test");
  var that = this;
  db.collection('InterviewTime').get({
    success: function(res){
      wx.stopPullDownRefresh();
      wx.hideLoading();
      //console.log(res);
      wx.setStorage({
        key: 'allTime',
        data: res.data
      });
      that.setData({
        all_time: res.data,
      })
    },fail: function () {
      wx.stopPullDownRefresh();
      wx.hideLoading();
      wx.getStorage({
        key: 'allTime',
        success: function (res) {
          that.setData({
            all_time: res.data,
          })
        },
        fail: function () {
          wx.showToast({
            title: '获取时间失败',
            image: '/images/fail.png',
            icon: 'fail',
            duration: 2000
          });
        }
      })
    }
  })    
}  ,
  tips:function(e)
  {
          var id = e.target.dataset.id;
          var that = this;
          let user = that.data.user;
          var stu_id = 0;
          var interview_id = 0;
          var last = 0;
          var forelast = 0;
          var backlast = 0;
          console.log(user)
          //console.log(id);
          this.getAllTime();
          for (var i = 0; i < that.data.all_time.length; i++) {
            if (that.data.all_time[i].num == id) {
              if (that.data.all_time[i].last > 0) {
                if(user.interviewNum == -1){
                  //-1说明还没选过
                  user.interviewNum = id;
                  //更新学生自己的信息
                  db.collection("Stu").where({
                    openid: user.openid
                  }).get({
                    success:function(res){
                      stu_id = res.data[0]._id
                      db.collection("Stu").doc(stu_id).update({
                        data:{
                          interviewNum: id
                        },
                        success: function(res){
                          //console.log(res)
                        }
                      })
                    }
                  })
                  //更新面试表的信息
                  db.collection("InterviewTime").where({
                    num : id
                  }).get({
                    success:function(res){
                      //console.log(res)
                      interview_id = res.data[0]._id
                      last = res.data[0].last
                      db.collection("InterviewTime").doc(interview_id).update({
                        data:{
                          last: last-1
                        },
                        success:function(res){
                          //console.log(res)
                          wx.showModal({
                            content: '提交成功',
                            showCancel: false
                          })
                        }
                      })
                    }
                  })
                }else{
                  //该学生已经选过了一个，但是又想改
                  var foreNum = user.interviewNum;
                    wx.showModal({
                      title: '提示',
                      content: '已选择场次，是否更改',
                      success(res) {
                        if (res.confirm) {
                          //console.log('用户点击确定');
                          user.interviewNum = id;
                          //更新学生自己的信息
                          db.collection("Stu").where({
                            openid: user.openid
                          }).get({
                            success:function(res){
                              stu_id = res.data[0]._id
                              db.collection("Stu").doc(stu_id).update({
                                data:{
                                  interviewNum: id
                                },
                                success: function(res){
                                  //console.log(res)
                                }
                              })
                            }
                          })
                          //更新上一次选的面试表的信息
                          db.collection("InterviewTime").where({
                            num : foreNum
                          }).get({
                            success:function(res){
                              //console.log(res)
                              interview_id = res.data[0]._id
                              forelast = res.data[0].last
                              //console.log(forelast+1)
                              db.collection("InterviewTime").doc(interview_id).update({
                                data:{
                                  last: forelast+1
                                },
                                success:function(res){
                                  //console.log(id)
                                  //更新这一次选的面试表的信息
                                  db.collection("InterviewTime").where({
                                    num : id
                                  }).get({
                                    success:function(res){
                                      //console.log(res)
                                      interview_id = res.data[0]._id
                                      backlast = res.data[0].last
                                      //console.log(backlast-1)
                                      db.collection("InterviewTime").doc(interview_id).update({
                                        data:{
                                          last: backlast-1
                                        },
                                        success:function(res){
                                          //console.log(res)
                                          wx.showModal({
                                            content: '提交成功',
                                            showCancel: false
                                          })
                                        }
                                      })
                                    }
                                  })
                    
                                }
                              })
                            },
                            fail:function(res){
                              //console.log(res)
                            }
                          })                        
                        }
                        else if (res.cancel) {
                        //  console.log('用户点击取消');
                        }
                      },
                      fail: function () {
                        wx.showToast({
                          title: '提交失败',
                          image: '/images/fail.png',
                        })
                      }
                    })
                }
              }else{
                //选择的场次没有剩余量
                wx.showModal({
                  content: '本场余量不足！！'
                })
              }
              break;
            }
            if(i == that.data.all_time.length-1)
            {
              //由于未知原因导致选择的号码在数据库中没有对应，大概率遭到删库
              wx.showToast({
                title: '系统出错，请联系科中成员',
                image: '/images/fail.png',
              })
            }
          }
        },
  dateToTimestamp(dateStr) {
    if (!dateStr) {
      return ''
    }
    let newDataStr = dateStr.replace(/\.|\-/g, '/')
    //let date = new Date(newDataStr);
    //let timestamp = date.getTime();
    return newDataStr;
  }
  })
    
