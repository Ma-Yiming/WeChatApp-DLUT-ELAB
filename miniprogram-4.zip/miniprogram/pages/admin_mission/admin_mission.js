// pages/admin_mission/admin_mission.js
const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    all_interview : [],
    user:"",
    flag:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.data.user = app.globalData.admin
    var that = this
    let user = this.data.user
    let userName = user.name
    var all_interview = [];
    //我们显示一个人负责哪个面试是通过名字，这可能有重名的现象，但是先不管~
    //console.log(userName)
    if(userName==''){
      userName = 'nan'
    } 
    db.collection("InterviewTime").where({
      name1:userName
    }).get({
      success:function(res){
        console.log(res)
        for(var i = 0;i<res.data.length;i++)
        {
          all_interview.push(res.data[i])
        }
        that.setData({
          all_interview:all_interview
        })
        console.log(that.data.all_interview)
        if(that.data.all_interview.length == 0){
          that.setData({
            flag:1
          })
        }else{
          that.setData({
            flag:0
          })
        }
      }
    })
    db.collection("InterviewTime").where({
      name2:userName
    }).get({
      success:function(res){
        console.log(res)
        for(var i = 0;i<res.data.length;i++)
        {
          all_interview.push(res.data[i])
        }
        that.setData({
          all_interview:all_interview
        })
        console.log(that.data.all_interview)
        if(that.data.all_interview.length == 0){
          that.setData({
            flag:1
          })
        }else{
          that.setData({
            flag:0
          })
        }
      }
    })
    db.collection("InterviewTime").where({
      name3:userName
    }).get({
      success:function(res){
        console.log(res)
        for(var i = 0;i<res.data.length;i++)
        {
          all_interview.push(res.data[i])
        }
        that.setData({
          all_interview:all_interview
        })
        console.log(that.data.all_interview)
        if(that.data.all_interview.length == 0){
          that.setData({
            flag:1
          })
        }else{
          that.setData({
            flag:0
          })
        }
      }
    })
    db.collection("InterviewTime").where({
      name4:userName
    }).get({
      success:function(res){
        console.log(res)
        for(var i = 0;i<res.data.length;i++)
        {
          all_interview.push(res.data[i])
        }
        that.setData({
          all_interview:all_interview
        })
        console.log(that.data.all_interview)
        if(that.data.all_interview.length == 0){
          that.setData({
            flag:1
          })
        }else{
          that.setData({
            flag:0
          })
        }
      }
    })
    db.collection("InterviewTime").where({
      name5:userName
    }).get({
      success:function(res){
        console.log(res)
        for(var i = 0;i<res.data.length;i++)
        {
          all_interview.push(res.data[i])
        }
        that.setData({
          all_interview:all_interview
        })
        console.log(that.data.all_interview)
        if(that.data.all_interview.length == 0){
          that.setData({
            flag:1
          })
        }else{
          that.setData({
            flag:0
          })
        }
      }
    })
    db.collection("InterviewTime").where({
      name6:userName
    }).get({
      success:function(res){
        console.log(res)
        for(var i = 0;i<res.data.length;i++)
        {
          all_interview.push(res.data[i])
        }
        that.setData({
          all_interview:all_interview
        })
        console.log(that.data.all_interview)
        if(that.data.all_interview.length == 0){
          that.setData({
            flag:1
          })
        }else{
          that.setData({
            flag:0
          })
        }
      }
    })
    db.collection("InterviewTime").where({
      name7:userName
    }).get({
      success:function(res){
        console.log(res)
        for(var i = 0;i<res.data.length;i++)
        {
          all_interview.push(res.data[i])
        }
        that.setData({
          all_interview:all_interview
        })
        console.log(that.data.all_interview)
        if(that.data.all_interview.length == 0){
          that.setData({
            flag:1
          })
        }else{
          that.setData({
            flag:0
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})