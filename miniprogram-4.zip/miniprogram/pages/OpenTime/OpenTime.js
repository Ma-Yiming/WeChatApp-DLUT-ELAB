// pages/OpenTime/OpenTime.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StartDate:"",
    StartTime:"",
    EndDate:"",
    EndTime:"",
    DelFore:""
  },
  bindStartDate: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      StartDate: e.detail.value
    })
  },
  bindStartTime: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      StartTime: e.detail.value
    })
  },
  bindEndDate: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      EndDate: e.detail.value
    })
  },
  bindEndTime: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      EndTime: e.detail.value
    })
  },
  upload:function(){
    var that = this;
    //必须要考虑表空和表非空两种情况，需要注意云函数是异步处理，所以不能写成直接串联形式就以为是串联，需要写成包含形式的
    db.collection("OpenTime").get({
      success:function(res){
        //console.log(res.data.length==0)
        //表空直接加
        if(res.data.length == 0)
        {
          db.collection("OpenTime").add({
            data:{
              StartDate:that.data.StartDate,
              StartTime:that.data.StartTime,
              EndDate:that.data.EndDate,
              EndTime:that.data.EndTime
            },
            success: function (res) {
              wx.showToast({
                title: '提交成功',
                icon: 'success',
                duration: 2000
              })
            },
            fail: function (res) {
              wx.showToast({
                title: '提交失败',
                image: '/images/fail.png',
                icon: 'fail',
                duration: 2000})}
          })
        }
        else
        {
          //表非空就先删掉之前那个，然后加，需要经过查找、删除、增加三个操作。
          //console.log(res.data[0]._id)
          that.data.DelFore=res.data[0]._id
          //console.log(that.data.DelFore)
          db.collection("OpenTime").doc(that.data.DelFore).remove({
            success:function(res){
              db.collection("OpenTime").add({
                data:{
                  StartDate:that.data.StartDate,
                  StartTime:that.data.StartTime,
                  EndDate:that.data.EndDate,
                  EndTime:that.data.EndTime
                },
                success: function (res) {
                  wx.showToast({
                    title: '提交成功',
                    icon: 'success',
                    duration: 2000
                  })
                },
                fail: function (res) {
                  wx.showToast({
                    title: '提交失败',
                    image: '/images/fail.png',
                    icon: 'fail',
                    duration: 2000})}
              })
            },fail:function(res){
              console.log("删除失败")
            }
          })
        }
      },
      fail: function(res){
        console.log(res)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})