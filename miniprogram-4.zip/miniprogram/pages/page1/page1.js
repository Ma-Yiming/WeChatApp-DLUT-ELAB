// pages/page1/page1.js
const app = getApp()
const db = wx.cloud.database()
var util = require('../../utils/utils.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var openid = app.globalData.openid;
    db.collection('Stu').where({
      openid:openid
    }).get({
      success: function(res){
        //返回当时的报名表以及选择的面试序号
        //console.log(res)
        //此人没有用这个openid报过名
        if(res.data == []){
          app.globalData.user = ''
        }
        else{
          //这里返回的是数组，取第一个
          app.globalData.user = res.data[0]
        }
        console.log(app.globalData.user)
      }
    })
    //获得开始和结束时间
    db.collection("OpenTime").get({
      success:function(res){
        //console.log(res.data[0])
        let start = res.data[0].StartDate+' '+res.data[0].StartTime;
        start = start.replace(/-/g, '/');
        var starttime = util.formatTime(new Date(start));
        let end = res.data[0].EndDate+' '+res.data[0].EndTime;
        end = end.replace(/-/g, '/');
        var endtime = util.formatTime(new Date(end));
        //console.log(starttime,endtime)
        app.globalData.starttime = starttime;
        app.globalData.endtime = endtime;
        //console.log(app.data.starttime,app.data.endtime)
      }
    })
    //这种console是经典错误，因为云函数是异步操作，这个时候还没有赋值，console不出来
    //console.log(app.globalData.endtime,app.globalData.starttime)
    //下边是设定level的，如果在admin表中就是管理员，等级设为1，默认是0
    db.collection("admin").where({
      openid:openid
    }).get({
      success:function(res){
        //存在
        //console.log(res)
        if(res.data.length > 0){
          app.globalData.level = 1
          app.globalData.admin = res.data[0]
        }
        db.collection("Sup_admin").where({
          openid:openid
        }).get({
          success:function(res){
            //console.log(res)
            if(res.data.length > 0){
              app.globalData.level = 2
            }
            //console.log(app.globalData.level)
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})