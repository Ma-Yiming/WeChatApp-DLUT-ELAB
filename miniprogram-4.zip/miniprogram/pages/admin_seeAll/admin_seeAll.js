// pages/admin_seeAll/admin_seeAll.js
const db = wx.cloud.database()
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    all_time: "",
    num:'',
    all_stu:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getAllTime();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showLoading({
      title: '加载中',
    });
    this.getAllTime();
    wx.stopPullDownRefresh();
    wx.hideLoading();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getAllTime: function () {
    wx.showLoading({
      title: '加载中',
    });
    //console.log("test");
    var that = this;
    db.collection('InterviewTime').get({
      success: function(res){
        wx.stopPullDownRefresh();
        wx.hideLoading();
        //console.log(res)
        wx.setStorage({
          key: 'allScore',
          data: res.data
        });
        that.setData({
          all_time:res.data,
        })
        //console.log(res)
      },
      fail: function () {
        wx.stopPullDownRefresh();
        wx.hideLoading();
        wx.getStorage({
          key: 'allTime',
          success: function (res) {
            that.setData({
              all_time: res.data,
            })
          },
          fail: function () {
            wx.showToast({
              title: '获取时间失败',
              image: '/images/fail1.png',
              icon: 'fail',
              duration: 2000
            });
          }
        })
      }
    })
  },
  tips:function(e){
    var that = this;
    var interviewNum = e.target.dataset.num
    db.collection('Stu').where({
      interviewNum:interviewNum
    })
    .get({
      success: function(res) {
        // res.data 是包含以上定义的两条记录的数组
        //console.log(res.data)
        that.setData({
          all_stu:res.data
        })
        var all_stu = JSON.stringify(that.data.all_stu)
        //var interviewNum = JSON.stringify(interviewNum)
        wx.navigateTo({
          url: '../admin_allStu/admin_allStu?all_stu='+all_stu+'&interviewNum='+interviewNum,
        })
      }
    })
  }
})